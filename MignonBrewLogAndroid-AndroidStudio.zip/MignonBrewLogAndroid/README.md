# Mignon Brew Log for Android

Version 3.1 of the Android app. This is an Android Studio project for an offline Android version of Mignon Brew Log. The app's HTML, JavaScript, styles, icon, and bundled Latin-script OCR model are packaged with the APK; it does not need a web connection or ChatGPT sign-in. OCR reads printed text from the bag and visible dial markings, then places suggestions in editable fields. The portafilter dropdown contains only the three selected Ascaso baskets. Saved coffee cards use a small thumbnail of the actual bag photo as the coffee icon. The WebView cache is disabled so changed bundled app files appear after installing an updated APK. The app attempts a no-tap reading: it crops the numbered grind dial, scans it in 12 rotations for OCR, and interpolates a two-decimal setting from 0.00 to 6.00 at the fixed index. The MAX/MIN control is estimated as a decimal from 0.00 at MIN to 8.00 at MAX. Dose dial reading compensates for the visible pointer offset; in the supplied photo, the pointer is a little past the first mark after MIN, around 1.1 on the 0.00–8.00 scale. These readings are estimates and remain editable; lighting, perspective, glare, or a tightly cropped photo can reduce accuracy.

## Build and install

1. Unzip this project and open the `MignonBrewLogAndroid` folder in Android Studio.
2. Let Gradle sync. Use JDK 17 and Android SDK Platform 35 when prompted.
3. Select **Build → Build APK(s)**. Android Studio writes the debug APK to `app/build/outputs/apk/debug/app-debug.apk`.
4. Install that APK on the Android device. Android may ask you to allow installation from the file manager or browser you used to open it.

This workspace did not have Android SDK or Gradle build tools available, so the APK itself could not be compiled here. The source project is ready for Android Studio to build. On-device text recognition currently targets Latin-script text; handwritten or Hebrew label text may not be recognized.

## Data and app updates

Entries and photos are stored in IndexedDB inside this app's private WebView data, on the phone. Normal app updates preserve that data when they use the same package ID (`com.orelbechler.mignonbrewlog`) and are signed with the same certificate. Android Studio's debug build uses its local debug key; keep using the same Android Studio installation for future debug updates. For release APKs, keep the release signing key safe and use it for every update.

Use **Backup** to save a JSON file with settings and photos to a location you choose. Use **Restore backup** to load it again. The web version and Android app have separate on-device storage, so export a backup from the web version and restore that file in the Android app if you want to copy existing entries.

Uninstalling the app or clearing its storage can erase the app's local data. Keep a backup somewhere outside the app.

## Project requirements

- Android Gradle Plugin 8.7.3
- Google ML Kit Text Recognition 16.0.1 (bundled Latin model)
- Android SDK Platform 35
- JDK 17
- Minimum Android version: Android 10 (API 29)

## Version 3.1
Redesigned mobile journal, larger dial readings, clearer photo cards, accessible controls, numeric range validation and decimal formatting. Pending recognition is discarded when forms close or reset. Recognition remains experimental; previous photo-specific offsets are not a general accuracy fix. Same application ID and database retain existing records during a compatible signed update.

Version 3.1: Apple-inspired system typography, photo-led cards, translucent primary action, reduced-motion support and grouped form controls. This remains an Android WebView app.
