package com.orelbechler.mignonbrewlog;

import android.app.Activity;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebChromeClient.FileChooserParams;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.util.Base64;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.IOException;
import java.io.OutputStream;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import org.json.JSONObject;
import org.json.JSONArray;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQUEST_PICK_FILE = 401;
    private static final int REQUEST_SAVE_BACKUP = 402;
    private static final String APP_HOST = "appassets.androidplatform.net";

    private WebView webView;
    private ValueCallback<Uri[]> fileChooserCallback;
    private Uri pendingCameraUri;
    private String pendingBackupJson;
    private TextRecognizer textRecognizer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getWindow().setStatusBarColor(0xFF183E32);
        getWindow().setNavigationBarColor(0xFF183E32);

        webView = findViewById(R.id.webview);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        webView.clearCache(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setSupportMultipleWindows(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.addJavascriptInterface(new BackupBridge(), "AndroidBackup");
        textRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        webView.addJavascriptInterface(new OcrBridge(), "AndroidOCR");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                return !APP_HOST.equals(uri.getHost()) && !"about".equals(uri.getScheme());
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (!"https".equals(uri.getScheme()) || !APP_HOST.equals(uri.getHost())) {
                    return super.shouldInterceptRequest(view, request);
                }
                String path = uri.getPath();
                if (path == null || path.equals("/")) path = "/index.html";
                if (path.startsWith("/assets/")) path = path.substring("/assets/".length());
                else if (path.startsWith("/")) path = path.substring(1);
                try {
                    String mime = mimeType(path);
                    return new WebResourceResponse(mime, mime.startsWith("text/") || mime.contains("javascript") || mime.contains("json") ? "UTF-8" : null,
                            getAssets().open(path));
                } catch (IOException notFound) {
                    return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", null,
                            new java.io.ByteArrayInputStream(new byte[0]));
                }
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileChooserCallback != null) fileChooserCallback.onReceiveValue(null);
                fileChooserCallback = callback;
                try {
                    Intent picker = params.createIntent();
                    Intent chooser = Intent.createChooser(picker, "Choose a photo or backup");
                    if (params.isCaptureEnabled() && acceptsImages(params)) {
                        Intent camera = makeCameraIntent();
                        if (camera != null) {
                            chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{camera});
                        }
                    }
                    startActivityForResult(chooser, REQUEST_PICK_FILE);
                    return true;
                } catch (Exception error) {
                    fileChooserCallback = null;
                    callback.onReceiveValue(null);
                    Toast.makeText(MainActivity.this, "Could not open files", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
        });

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState);
        }
        if (webView.getUrl() == null) {
            webView.loadUrl("https://" + APP_HOST + "/index.html");
        }
    }

    private static String mimeType(String path) {
        String lower = path.toLowerCase(Locale.ROOT);
        if (lower.endsWith(".html")) return "text/html";
        if (lower.endsWith(".js")) return "application/javascript";
        if (lower.endsWith(".webmanifest")) return "application/manifest+json";
        if (lower.endsWith(".json")) return "application/json";
        if (lower.endsWith(".svg")) return "image/svg+xml";
        String guessed = URLConnection.guessContentTypeFromName(path);
        return guessed == null ? "application/octet-stream" : guessed;
    }

    private static boolean acceptsImages(FileChooserParams params) {
        String[] types = params.getAcceptTypes();
        for (String type : types) if (type != null && type.startsWith("image/")) return true;
        return false;
    }

    private Intent makeCameraIntent() {
        Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (camera.resolveActivity(getPackageManager()) == null) return null;
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.DISPLAY_NAME, "brew-log-" + System.currentTimeMillis() + ".jpg");
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
        values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Mignon Brew Log");
        pendingCameraUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        if (pendingCameraUri == null) return null;
        camera.putExtra(MediaStore.EXTRA_OUTPUT, pendingCameraUri);
        camera.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        camera.setClipData(ClipData.newRawUri("Photo", pendingCameraUri));
        return camera;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_PICK_FILE) {
            Uri selected = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getData() != null) selected = data.getData();
                else if (data.getClipData() != null && data.getClipData().getItemCount() > 0) {
                    selected = data.getClipData().getItemAt(0).getUri();
                }
            }
            if (selected == null && resultCode == RESULT_OK) selected = pendingCameraUri;
            if (pendingCameraUri != null && !pendingCameraUri.equals(selected)) {
                getContentResolver().delete(pendingCameraUri, null, null);
            }
            if (fileChooserCallback != null) {
                fileChooserCallback.onReceiveValue(selected == null ? null : new Uri[]{selected});
                fileChooserCallback = null;
            }
            pendingCameraUri = null;
        } else if (requestCode == REQUEST_SAVE_BACKUP) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingBackupJson != null) {
                try (OutputStream output = getContentResolver().openOutputStream(data.getData())) {
                    if (output == null) throw new IOException("No output stream");
                    output.write(pendingBackupJson.getBytes(StandardCharsets.UTF_8));
                    Toast.makeText(this, "Backup saved", Toast.LENGTH_SHORT).show();
                } catch (IOException error) {
                    Toast.makeText(this, "Could not save backup", Toast.LENGTH_LONG).show();
                }
            }
            pendingBackupJson = null;
        }
    }

    public class OcrBridge {
        @JavascriptInterface
        public void recognizePhoto(String requestId, String photoKey, String dataUrl) {
            Bitmap bitmap = null;
            try {
                int comma = dataUrl.indexOf(',');
                String encoded = comma >= 0 ? dataUrl.substring(comma + 1) : dataUrl;
                byte[] bytes = Base64.decode(encoded, Base64.DEFAULT);
                bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                if (bitmap == null) throw new IllegalArgumentException("Invalid image");
                if ("grindPhoto".equals(photoKey)) {
                    int side = Math.min(Math.round(bitmap.getHeight() * 0.72f), Math.round(bitmap.getWidth() * 0.38f));
                    int left = Math.max(0, Math.min(bitmap.getWidth() - side, Math.round(bitmap.getWidth() * 0.48f - side / 2f)));
                    int top = Math.max(0, Math.min(bitmap.getHeight() - side, Math.round(bitmap.getHeight() * 0.49f - side / 2f)));
                    Bitmap dialCrop = Bitmap.createBitmap(bitmap, left, top, side, side);
                    bitmap.recycle();
                    recognizeRotatedGrindDial(requestId, photoKey, dialCrop, left, top, 0, new StringBuilder(), new JSONArray());
                } else {
                    recognizeOrdinaryPhoto(requestId, photoKey, bitmap);
                }
            } catch (Exception error) {
                if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
                sendOcrResult(requestId, photoKey, "", "Could not read image", new JSONArray());
            }
        }
    }

    private void recognizeOrdinaryPhoto(String requestId, String photoKey, Bitmap bitmap) {
        InputImage image = InputImage.fromBitmap(bitmap, 0);
        textRecognizer.process(image)
                .addOnSuccessListener(result -> {
                    JSONArray detections = new JSONArray();
                    for (com.google.mlkit.vision.text.Text.TextBlock block : result.getTextBlocks()) {
                        for (com.google.mlkit.vision.text.Text.Line line : block.getLines()) {
                            android.graphics.Rect box = line.getBoundingBox();
                            if (box == null) continue;
                            JSONObject item = new JSONObject();
                            try {
                                item.put("text", line.getText());
                                item.put("x", box.left);
                                item.put("y", box.top);
                                item.put("width", box.width());
                                item.put("height", box.height());
                                detections.put(item);
                            } catch (org.json.JSONException ignored) { }
                        }
                    }
                    sendOcrResult(requestId, photoKey, result.getText(), "", detections);
                })
                .addOnFailureListener(error -> sendOcrResult(requestId, photoKey, "", "OCR failed", new JSONArray()))
                .addOnCompleteListener(task -> bitmap.recycle());
    }

    private void recognizeRotatedGrindDial(String requestId, String photoKey, Bitmap crop, int cropLeft, int cropTop,
                                           int step, StringBuilder allText, JSONArray detections) {
        if (step >= 12) {
            if (!crop.isRecycled()) crop.recycle();
            sendOcrResult(requestId, photoKey, allText.toString(), "", detections);
            return;
        }
        int degrees = step * 30;
        Bitmap rotated = Bitmap.createBitmap(crop.getWidth(), crop.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(rotated);
        canvas.drawColor(0xFF101010);
        Matrix matrix = new Matrix();
        matrix.setRotate(degrees, crop.getWidth() / 2f, crop.getHeight() / 2f);
        canvas.drawBitmap(crop, matrix, new Paint(Paint.FILTER_BITMAP_FLAG));
        InputImage image = InputImage.fromBitmap(rotated, 0);
        textRecognizer.process(image)
                .addOnSuccessListener(result -> {
                    if (result.getText() != null && !result.getText().isEmpty()) allText.append(result.getText()).append('\n');
                    float cx = crop.getWidth() / 2f, cy = crop.getHeight() / 2f;
                    double radians = Math.toRadians(degrees), cos = Math.cos(radians), sin = Math.sin(radians);
                    for (com.google.mlkit.vision.text.Text.TextBlock block : result.getTextBlocks()) {
                        for (com.google.mlkit.vision.text.Text.Line line : block.getLines()) {
                            String value = line.getText() == null ? "" : line.getText().trim().replaceAll("[^0-5]", "");
                            if (!value.matches("[0-5]")) continue;
                            android.graphics.Rect box = line.getBoundingBox();
                            if (box == null) continue;
                            float rx = box.centerX() - cx, ry = box.centerY() - cy;
                            float originalX = (float) (cx + cos * rx + sin * ry) + cropLeft;
                            float originalY = (float) (cy - sin * rx + cos * ry) + cropTop;
                            addUniqueDialNumber(detections, value, originalX, originalY);
                        }
                    }
                })
                .addOnFailureListener(error -> { })
                .addOnCompleteListener(task -> {
                    if (!rotated.isRecycled()) rotated.recycle();
                    recognizeRotatedGrindDial(requestId, photoKey, crop, cropLeft, cropTop, step + 1, allText, detections);
                });
    }

    private void addUniqueDialNumber(JSONArray detections, String value, float x, float y) {
        for (int i = 0; i < detections.length(); i++) {
            JSONObject existing = detections.optJSONObject(i);
            if (existing == null || !value.equals(existing.optString("text"))) continue;
            if (Math.hypot(existing.optDouble("x") - x, existing.optDouble("y") - y) < 45) return;
        }
        JSONObject item = new JSONObject();
        try {
            item.put("text", value);
            item.put("x", x);
            item.put("y", y);
            item.put("width", 0);
            item.put("height", 0);
            detections.put(item);
        } catch (org.json.JSONException ignored) { }
    }

    private void sendOcrResult(String requestId, String photoKey, String text, String error, JSONArray detections) {
        String javascript = "window.onOcrComplete&&window.onOcrComplete("
                + JSONObject.quote(requestId) + "," + JSONObject.quote(photoKey) + ","
                + JSONObject.quote(text == null ? "" : text) + "," + JSONObject.quote(error) + "," + (detections == null ? "[]" : detections.toString()) + ");";
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(javascript, null);
        });
    }

    public class BackupBridge {
        @JavascriptInterface
        public void saveBackupJson(String json) {
            runOnUiThread(() -> {
                pendingBackupJson = json;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, "mignon-brew-log-backup.json");
                try {
                    startActivityForResult(intent, REQUEST_SAVE_BACKUP);
                } catch (Exception error) {
                    pendingBackupJson = null;
                    Toast.makeText(MainActivity.this, "Could not open save dialog", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (webView != null) webView.saveState(outState);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (fileChooserCallback != null) fileChooserCallback.onReceiveValue(null);
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidBackup");
            webView.removeJavascriptInterface("AndroidOCR");
            webView.destroy();
        }
        if (textRecognizer != null) textRecognizer.close();
        super.onDestroy();
    }
}
